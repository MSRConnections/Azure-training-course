<!DOCTYPE html>
<html>
<head>
    <title>Windows Azure Web Sites - Hello World sample!</title>
</head>

<body>
    <h1>Windows Azure Web Sites - Hello World sample!</h1>

<?php
    // Show all information, defaults to INFO_ALL
    phpinfo();
?>
</body>
</html>
